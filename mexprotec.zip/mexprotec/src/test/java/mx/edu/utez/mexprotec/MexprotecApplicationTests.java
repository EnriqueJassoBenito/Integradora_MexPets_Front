package mx.edu.utez.mexprotec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MexprotecApplicationTests {

	@Test
	void contextLoads() {
	}

}
